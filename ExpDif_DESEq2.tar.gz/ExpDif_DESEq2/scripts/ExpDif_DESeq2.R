######################################################
# Expresion dierencial con DESeq2
######################################################

# Si aun no has cargado las bibliotecas ejecuta:

if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("DESeq2")
BiocManager::install("reshape2")

# Ahora cargamos los valores
library(DESeq2)
library(reshape2)
library(ggplot2)

#-----------------------------------------------------
# 1. Leyendo la tabla de conteos y visualizando los 
# primeros renglones
#-----------------------------------------------------
CT<-read.table("data/pasilla_gene_counts.txt",header=T, sep="\t",row.names = 1)
head(CT)


#-----------------------------------------------------
# Transformacion log2 de los datos 
# (pseudo normalizacion)
#-----------------------------------------------------
pseudoCT = log2(CT  + 1)

#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# 2. Seccion Análisis de datos
#-----------------------------------------------------
# Transformando las columnas en renglones con la 
# funcion melt del paquete reshape2
#-----------------------------------------------------

pseudoCT_M = melt(pseudoCT, variable.name = "Samples",id.vars=NULL)
head(pseudoCT_M)
tail(pseudoCT_M)
# Agregando la columna Cond al data.frame pseudoCT_M
pseudoCT_M$Cond=sub("_.$","",pseudoCT_M$Samples)
head(pseudoCT_M)

#-----------------------------------------------------
# Distribucion de conteos entre las muestras
# grafica de boxplot
#-----------------------------------------------------
ggplot(pseudoCT_M, aes(x = Samples, y = value, fill = Cond)) + 
  geom_boxplot() + ylab("pseudoCount") + theme_void()

ggsave("resultados/boxplot.pdf")

#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# Seccion Graficas de multipaneles
#-----------------------------------------------------
# Graficas de densidad, para visualizar semejanza 
# entre las replicas
#-----------------------------------------------------
ggplot(pseudoCT_M, aes(x = value, colour = Samples, 
                       fill = Samples)) +
  geom_density(alpha = 0.2) + facet_wrap(~ Cond) +theme_bw()

ggsave("resultados/densidad.pdf")


######################################################
# 3. Seccion Filtrado de datos
######################################################

#-----------------------------------------------------
# Filtrando con los genes con conteos poco 
# significativos y generando una tabla con cuentas
# filtradas.
#-----------------------------------------------------
smallestGroupSize <- 3
keep<-rowSums(CT > 5) >= smallestGroupSize
head(keep)
CT_Filter<- CT[keep, ]
dim(CT_Filter)
dim(CT)

#-----------------------------------------------------
# Constuyendo un data.frame con la informacion de las
# muestras y condiciones
#-----------------------------------------------------
# Como nuestras muestras siguen un patron en su nombre
# podemos formar el vector conditions de la siguiente
# manera
names(CT_Filter)
cond<-factor(sub("_.$","",names(CT_Filter)))

cond
expDesign<-data.frame(row.names=colnames(CT_Filter),
                      condition =cond)
expDesign

#------------------------------------------------------
# Crear el objeto DESeqData, por medio de la funcion 
# DESeqDataSetFromMatrix.
#-------------------------------------------------------
cds<-DESeqDataSetFromMatrix(countData =as.matrix(CT_Filter),
                            colData = expDesign,design = ~ condition)
cds

#-------------------------------------------------------
# Haciendo la grafica de componentes principales pca
#-------------------------------------------------------
fnRld<-rlogTransformation(cds)
plotPCA(fnRld, intgroup="condition")

# Como esta funcion esta hecha en ggplot2, podemos agregar
# mas capas, por ejemplo:
plotPCA(fnRld, intgroup="condition")+
  theme_bw() +
  labs(title = "PCA") + 
  geom_text(aes(label=colnames(fnRld)), vjust=-0.5,size=2)

#--------------------------------------------------------
# Haciendo la Normalizacionn,Calculo de dispersion y la
# Prueba de hipotesis
#--------------------------------------------------------
cds <- DESeq(cds)
resDESeq <- data.frame(results(cds))
head(resDESeq,3)
dim(resDESeq)

genesUP_DEseq<-resDESeq[resDESeq$log2FoldChange >=1.5 & resDESeq$padj <= 0.01,]
nrow(genesUP_DEseq)

genesDOWN_DEseq<-resDESeq[resDESeq$log2FoldChange <= -1.5 & resDESeq$padj <= 0.01,]
nrow(genesDOWN_DEseq)

#--------------------------------------------------------
# Agregando la informacion de la expresion al data.frame
#--------------------------------------------------------
resDESeq$Expresion<-"non-DE"
resDESeq[row.names(genesUP_DEseq),'Expresion']<-"Up_untreated"
resDESeq[row.names(genesDOWN_DEseq),'Expresion']<-"Down_untreated"
genesUp<-resDESeq[row.names(genesUP_DEseq),]


#-------------------------------------------------------
# Escribiendo los resultados en archivos
#-------------------------------------------------------
write.table(resDESeq,"resultados/All_Results_DESeq.txt",sep="\t",quote=F)
write.table(genesUP_DEseq,"resultados/UpGenes_Results_DESeq.txt",sep="\t",quote=F)
write.table(genesDOWN_DEseq,"resultados/DownGenes_Results_DESeq.txt",sep="\t",quote=F)

